SQLALCHEMY_DATABASE_URI = "mysql+mysqlconnector://cpaneluser_myuser:password@localhost/cpaneluser_mydb_2"

ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "911"

SECRET_KEY = "saj%!@$$%$!@jhdfjsdgfjgs!^@&%&^#!@&$jhdsjfdsf546546446465"